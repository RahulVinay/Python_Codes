import openpyxl
import configparser
import re

FUNC_DESC = "update function description"
FUNC_HEADER = "description in function header"
ROBUST_TEST = " different values of as per robustness"
ER_MISSING_DETAILS = "missing in ER table"
IC_MISSING_DETAILS = "missing in IC table"
VT_MISSING_DETAILS = "missing in Vector table"
REMOVE_PRINT = "remove debug print"
SUB_CMD = "add sub command in algo"

defect_class_dict = {
    FUNC_DESC : "Standard/Compliance"
    FUNC_HEADER : "Code Formatting"
    FUNC_HEADER : "Code Formatting"
    ROBUST_TEST : "Functional"
    ER_MISSING_DETAILS = : "Standard/Compliance"
    IC_MISSING_DETAILS = : "Standard/Compliance"
    VT_MISSING_DETAILS = : "Standard/Compliance"
}

DEFECT_TYPE = 2
VERSION = 4
REVIEWER = 5
DATE_OF_DEFECT_LOGGING = 6
DEFECT_DESCRIPTION = 7
ACTIONS = 8
DEFECT_CLASSIFICATION = 9
SEVERITY = 10
PRIORITY = 11
FOUND_IN_VER = 12
TARGET_VER = 13
DEFECT_REPORTED_BY = 14
ASSIGNED_TO = 15
RESOLUTION = 18
STATUS = 19
DATE_OF_RESOLUTION = 20
VERIFIED_CLOSED_DATE = 21

parser = configparser.ConfigParser()
parser.read('config.ini')

path = parser['Fields']['PATH']
tab = parser['Fields']['TAB']
book = openpyxl.load_workbook(path)
sheet = book[tab]

    
for row_num in range(2, sheet.max_row + 1):
        if sheet.cell(row = row_num,column = DEFECT_DESCRIPTION).value is not None:
            if DOXYGEN in sheet.cell(row = row_num,column = DEFECT_DESCRIPTION).value:
                sheet.cell(row = row_num,column = DEFECT_CLASSIFICATION).value = "Documentation - Information Inconsistency"
            sheet.cell(row = row_num,column = DEFECT_TYPE).value = parser['Fields']['DEFECT_TYPE']
            sheet.cell(row = row_num,column = VERSION).value = parser['Fields']['VERSION']
            sheet.cell(row = row_num,column = REVIEWER).value = parser['Fields']['REVIEWER']
            sheet.cell(row = row_num,column = DATE_OF_DEFECT_LOGGING).value = parser['Fields']['DATE_OF_DEFECT_LOGGING']
            sheet.cell(row = row_num,column = FOUND_IN_VER).value = parser['Fields']['FOUND_IN_VER']
            sheet.cell(row = row_num,column = TARGET_VER).value = parser['Fields']['TARGET_VER']
            sheet.cell(row = row_num,column = SEVERITY).value = parser['Fields']['SEVERITY']
            sheet.cell(row = row_num,column = PRIORITY).value = parser['Fields']['PRIORITY']
            if sheet.cell(row = row_num,column = ACTIONS).value == "Accepted":
                sheet.cell(row = row_num,column = RESOLUTION).value = parser['Fields']['RESOLUTION']
                sheet.cell(row = row_num,column = STATUS).value = parser['Fields']['STATUS']
            sheet.cell(row = row_num,column = DEFECT_REPORTED_BY).value = parser['Fields']['DEFECT_REPORTED_BY']
            sheet.cell(row = row_num,column = ASSIGNED_TO).value = parser['Fields']['ASSIGNED_TO']
            sheet.cell(row = row_num,column = DATE_OF_RESOLUTION).value = parser['Fields']['DATE_OF_RESOLUTION']
            sheet.cell(row = row_num,column = VERIFIED_CLOSED_DATE).value = parser['Fields']['VERIFIED_CLOSED_DATE']
                
book.save(path)